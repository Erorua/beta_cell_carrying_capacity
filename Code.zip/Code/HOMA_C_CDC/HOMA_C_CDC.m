function HOMA_C_CDC_American_dataset_1999_2018


% ============================================================================================
% Description
% ============================================================================================


%%% Author: Aurore Woller

%%% Date: December 2023

%%% Uni: Weizmann institute of Science

%%% Description: HOMA-C calculation from CDC dataset








% ============================================================================================
% Main
% ============================================================================================



%%% Preprocessed CDC data from 1999 to 2018

% column1:index; column2:glucose; column3:insulin; column4:age; column5: bmi; column6:HOMA-C


x9900=load('./Output/Preprocessing_1999_2000.txt');

x0102=load('./Output/Preprocessing_2001_2002.txt');

x0304=load('./Output/Preprocessing_2003_2004.txt');

x0506=load('./Output/Preprocessing_2005_2006.txt');

x0708=load('./Output/Preprocessing_2007_2008.txt');

x0910=load('./Output/Preprocessing_2009_2010.txt');

x0910=load('./Output/Preprocessing_2009_2010.txt');

x1112=load('./Output/Preprocessing_2011_2012.txt');

x1314=load('./Output/Preprocessing_2013_2014.txt');

x1516=load('./Output/Preprocessing_2015_2016.txt');

x1718=load('./Output/Preprocessing_2017_2018.txt');


Table_pre=[x9900;x0102;x0304;x0506;x0708;x0910;x1112;x1314;x1516;x1718]; % c1:index; c2:glucose; c3:insulin; c4:age; c5: bmi; c6:HOMA-C

npre=length(Table_pre(:,1))


A=[Table_pre(:,2) Table_pre(:,3)];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Remove  glucose insulin outliers

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



B = rmoutliers(A,"percentiles",[2.5 97.5]);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Remove BMI outliers

Store_pre=[];

for i=1:length(Table_pre(:,1))





        [tf, index]=ismember(Table_pre(i,2:3),B(:,1:2),'rows');
   




if tf==0 % empty   %%%  is an outlier


  xxx=1;
 

else % is not an outlier


      
Store_pre=[Store_pre;Table_pre(i,1) Table_pre(i,2) Table_pre(i,3) Table_pre(i,4) Table_pre(i,5) Table_pre(i,6)];




end






end


ktest=find(Store_pre(:,2)>6.9);


Store_pre(ktest,:);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


B0 = rmoutliers(Store_pre(:,5),"percentiles",[2.5 97.5]);


% 
Store_pre0=[];

for i=1:length(Store_pre(:,1))





        [tf0, index0]=ismember(Store_pre(i,5),B0(:,1),'rows');
   




if tf0==0 % empty   %%%  is an outlier


  xxx0=1;
 

else % is not an outlier


      
Store_pre0=[Store_pre0;Store_pre(i,1) Store_pre(i,2) Store_pre(i,3) Store_pre(i,4) Store_pre(i,5) Store_pre(i,6)];




end






end









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Separate prediabetic  and diabetitc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



Prediab=[];



Diab=[];

for i=1:length(Store_pre0(:,1))

if Store_pre0(i,2) > 6.9

Diab=[Diab;Store_pre0(i,:)];

xxx=1;


else


Prediab=[Prediab;Store_pre0(i,:)];

end


end

%Prediab(1:100,:)


Diab;









%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%% Density Plot -  Prediabetic  -Insulin vs Glucose
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







figure(1)




subplot(2,2,1)


x=Prediab(:,2);% Glucose

y=Prediab(:,3);% Insulin


xmax=max(x);

xmin=min(x);

[counts,centers] = hist(x)

bar(centers,counts/trapz(centers,counts))



hold on;
% 


ksdensity(x,'Support',[xmin*(1-0.0001) xmax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',0.05);


 
 xlabel('Glucose')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);
 


P = prctile(x,10)

fp=ksdensity(x,P,'Support','positive','BoundaryCorrection','reflection','Bandwidth',0.05)






subplot(2,2,2)

x=Prediab(:,2);% Glucose

y=Prediab(:,3);% Insulin

ymin=min(y);

ymax=max(y);

[counts,centers] = hist(y)

bar(centers,counts/trapz(centers,counts))

hold on;

ksdensity(y,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',1);


P = prctile(y,50)


fp=ksdensity(y,P,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',1)
 
 xlabel('Insulin')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);


z=[y];

zz=[];

for i=1:length(z(:,1))



    if  z(i,1) < P(:,1) 

    elseif  z(i,1) > P(:,1) 




zz=[zz;z(i,1) ];


    end


end

prop=length(zz)/length(y)




 

subplot(2,2,3)



x=Prediab(:,2);% Glucose

y=Prediab(:,3);% Insulin

ymin=min(y)

ymax=max(y)

xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];



Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)]

ksdensity([x y],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 1]);



ndata=length(x)

nmesh=length(ksdensity([x y],xi,'Support','positive','BoundaryCorrection','reflection','Bandwidth',[0.05 1]))

 hold on

 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


hold on;




subplot(2,2,4)


x=Prediab(:,2);% Glucose

y=Prediab(:,3);% Insulin

ymin=min(y);

ymax=max(y);


xmax=max(x);

xmin=min(x);

xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];


Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)];






 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


[fxy xy]=ksdensity([x y],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 1]);



vq = griddata(xy(:,1),xy(:,2),fxy,x,y);


% 
Sck=[x y vq];

[Sckss,I] = sort(Sck(:,3),'descend');

Sckend=Sck(I,:);


% Contour with 50% of people

S50=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S50(:,1))  < 0.50*length(Sckend(:,1))


      S50=[S50;Sckend(i,:)];

  else


  end

    else 

          S50=[S50;Sckend(i,:)];


   end



end



prop=length(S50(:,1)) /length(Sckend(:,1))

length(S50(:,1)) 






% Contour with 25 % of people

S25=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S25(:,1))  < 0.250*length(Sckend(:,1))


      S25=[S25;Sckend(i,:)];

  else


  end

    else 

          S25=[S25;Sckend(i,:)];


   end



end



prop=length(S25(:,1)) /length(Sckend(:,1));

length(S25(:,1)) ;




  % Contour with 75 % of people

S75=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S75(:,1))  < 0.750*length(Sckend(:,1))


      S75=[S75;Sckend(i,:)];

  else


  end

    else 

          S75=[S75;Sckend(i,:)];


   end



end



prop=length(S75(:,1)) /length(Sckend(:,1));

length(S75(:,1));




 plot(Prediab(:,2),Prediab(:,3),'Marker','.','LineStyle','none','Color',[0.650980392156863 0.650980392156863 0.650980392156863])

 hold on;


k = boundary(S50(:,1),S50(:,2),0.5);


plot(S50(k,1),S50(k,2))

hold on;

k = boundary(S25(:,1),S25(:,2),0.5);



plot(S25(k,1),S25(k,2))

hold on;

k = boundary(S75(:,1),S75(:,2),0.5);



plot(S75(k,1),S75(k,2))

hold on;



 xlabel('Glucose')


  ylabel('Insulin')


  legend('','50%','25%','75%')


  figure(3)

  subplot(2,3,1)

   plot(Prediab(:,2),Prediab(:,3),'Marker','.','LineStyle','none','Color',[0.9 0.9 0.9])

 hold on;


k = boundary(S50(:,1),S50(:,2),0.5);


plot(S50(k,1),S50(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;

k = boundary(S25(:,1),S25(:,2),0.5);


plot(S25(k,1),S25(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;



k = boundary(S75(:,1),S75(:,2),0.5);

plot(S75(k,1),S75(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;



 xlabel('Glucose')


  ylabel('Insulin')


 % legend('','50%','25%','75%')




annotation(figure(3),'textbox',[0.146833333333334 0.670200235571256 0.0108055555555554 0.0282685512367489],'Color',[0.65 0.65 0.65],'String',{'75%'}, 'FontSize',8, 'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox',[0.187111111111111 0.637220259128383 0.0226111111111112 0.0282685512367491], 'Color',[1 0 0], 'String','25%','FontSize',8,'FitBoxToText','off', 'EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox', [0.210722222222222 0.673733804475851 0.0226111111111112 0.0282685512367491], 'Color',[1 0 0], 'String','50%','FontSize',8, 'FitBoxToText','off', 'EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox',[0.1385 0.641931684334508 0.0108055555555555 0.0282685512367488],'Color',[0.65 0.65 0.65],'String','50%','FontSize',8, 'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox',[0.132944444444445 0.618374558303884 0.0108055555555556 0.0282685512367488],'Color',[0.65 0.65 0.65],'String','25%', 'FontSize',8, 'FitBoxToText','off', 'EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox', [0.2635 0.731448763250883 0.0226111111111111 0.0282685512367491],'Color',[1 0 0],'String','75%','FontSize',8,'FitBoxToText','off','EdgeColor','none');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  Density Plot - Diabetic - Glucose vs Insulin
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







figure(2)





Gi=Diab(:,2);% Glucose

Ii=Diab(:,3);% Insulin




subplot(2,2,1)


x=Diab(:,2);% Glucose

y=Diab(:,3);% Insulin


xmax=max(x);

xmin=min(x);

[counts,centers] = hist(x)

bar(centers,counts/trapz(centers,counts))



hold on;
% 


ksdensity(x,'Support',[xmin*(1-0.0001) xmax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',0.1);


 
 xlabel('Glucose')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);
 


P = prctile(x,10)

fp=ksdensity(x,P,'Support','positive','BoundaryCorrection','reflection','Bandwidth',0.05)






subplot(2,2,2)

x=Diab(:,2);% Glucose

y=Diab(:,3);% Insulin

ymin=min(y);

ymax=max(y);

[counts,centers] = hist(y)

bar(centers,counts/trapz(centers,counts))

hold on;

ksdensity(y,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',1);


P = prctile(y,50)


fp=ksdensity(y,P,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',1)
 
 xlabel('Insulin')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);


z=[y];

zz=[];

for i=1:length(z(:,1))



    if  z(i,1) < P(:,1) 

    elseif  z(i,1) > P(:,1) 




zz=[zz;z(i,1) ];


    end


end

prop=length(zz)/length(y)




 

subplot(2,2,3)



x=Diab(:,2);% Glucose

y=Diab(:,3);% Insulin

ymin=min(y)

ymax=max(y)

xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];

%ksdensity([x y],xi,'Support','positive','BoundaryCorrection','reflection','Bandwidth',[0.05 1]);

Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)]

ksdensity([x y],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.1 1]);



ndata=length(x)

nmesh=length(ksdensity([x y],xi,'Support','positive','BoundaryCorrection','reflection','Bandwidth',[0.1 1]))

 hold on

 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


hold on;




subplot(2,2,4)


x=Diab(:,2);% Glucose

y=Diab(:,3);% Insulin

ymin=min(y);

ymax=max(y);


xmax=max(x);

xmin=min(x);

xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];


Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)];

%ksdensity([x y],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 1]);




 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


[fxy xy]=ksdensity([x y],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 1]);



vq = griddata(xy(:,1),xy(:,2),fxy,x,y);


% 
Sck=[x y vq];

[Sckss,I] = sort(Sck(:,3),'descend');

Sckend=Sck(I,:);


% Contour with 50% of people

S50=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S50(:,1))  < 0.50*length(Sckend(:,1))


      S50=[S50;Sckend(i,:)];

  else


  end

    else 

          S50=[S50;Sckend(i,:)];


   end



end



prop=length(S50(:,1)) /length(Sckend(:,1))

length(S50(:,1)) 






% Contour with 25 % of people

S25=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S25(:,1))  < 0.250*length(Sckend(:,1))


      S25=[S25;Sckend(i,:)];

  else


  end

    else 

          S25=[S25;Sckend(i,:)];


   end



end



prop=length(S25(:,1)) /length(Sckend(:,1));

length(S25(:,1)) ;




  % Contour with 75 % of people

S75=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S75(:,1))  < 0.750*length(Sckend(:,1))


      S75=[S75;Sckend(i,:)];

  else


  end

    else 

          S75=[S75;Sckend(i,:)];


   end



end



prop=length(S75(:,1)) /length(Sckend(:,1));

length(S75(:,1));




 plot(Diab(:,2),Diab(:,3),'Marker','.','LineStyle','none','Color',[0.650980392156863 0.650980392156863 0.650980392156863])

 hold on;






k = boundary(S50(:,1),S50(:,2),0.5);

plot(S50(k,1),S50(k,2))

hold on;



k = boundary(S25(:,1),S25(:,2),0.5);

plot(S25(k,1),S25(k,2))

hold on;



k = boundary(S75(:,1),S75(:,2),0.5);

plot(S75(k,1),S75(k,2))

hold on;



 xlabel('Glucose')


  ylabel('Insulin')


  legend('','50%','25%','75%')

 


  figure(3)

   plot(Diab(:,2),Diab(:,3),'Marker','.','LineStyle','none','Color',[0.9 0.9 0.9])

 hold on;


k = boundary(S50(:,1),S50(:,2),0.5);



plot(S50(k,1),S50(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;

k = boundary(S25(:,1),S25(:,2),0.5);



plot(S25(k,1),S25(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;



k = boundary(S75(:,1),S75(:,2),0.5);

plot(S75(k,1),S75(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;



 xlabel('Glucose')


  ylabel('Insulin')






x = 5.59:0.01:13.5;
y = 3:0.01:65;% 



[x1,y1] = meshgrid(sort(x),sort(y));

v = 20*x1.*y1./((x1-3.5).*(x1-4.8));


hold on;




[c,h]=contour(x1,y1,v,10,'LineWidth', 2,'LevelList',[100 200 300 600 900 1200]);

clabel(c,h,'labelspacing', 700);


hold on;




cb = colorbar; 


title(cb,'HOMA-C');


xlabel('Glucose (mmol/L)')

ylabel('Insulin (\muU/L')

set(gca,'FontName','Arial','FontSize',20);


pbaspect([1 1 1])

%legend('HOMA-C')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  Density Plot - Prediabetic  - HOMA-B -HOMA-IR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(4)

subplot(2,2,1)

x=Prediab(:,2);% Glucose

y=Prediab(:,3);% Insulin


y2=20*y./(x-3.5) ; %HOMAB

x2=22.5./(x.*y); %1/HOMA_IR


xmax=max(x2);

xmin=min(x2);

[counts,centers] = hist(x2);

bar(centers,counts/trapz(centers,counts));



hold on;
% 



ksdensity(x2,'Support',[xmin*(1-0.0001) xmax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',0.05);





 
 xlabel('1/HOMA-IR')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);


subplot(2,2,2)



ymin=min(y2);

ymax=max(y2);

[counts,centers] = hist(y2)

bar(centers,counts/trapz(centers,counts))

hold on;

ksdensity(y2,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',5);


 xlabel('HOMA-B')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);



subplot(2,2,3)



xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];



Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)]

ksdensity([x2 y2],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 5]);



ndata=length(x)

nmesh=length(ksdensity([x2 y2],xi,'Support','positive','BoundaryCorrection','reflection','Bandwidth',[0.05 5]))

 hold on

 xlabel('1/HOMA-IR')
 
 ylabel('HOMA-B')
 
 zlabel('Joint Probability')

hold on;


hold on;

subplot(2,2,4)




xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];


Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)];





 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


[fxy xy]=ksdensity([x2 y2],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 5]);



vq = griddata(xy(:,1),xy(:,2),fxy,x2,y2);


% 
Sck=[x2 y2 vq];

[Sckss,I] = sort(Sck(:,3),'descend');

Sckend=Sck(I,:);


% Contour with 50% of people

S50=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S50(:,1))  < 0.50*length(Sckend(:,1))


      S50=[S50;Sckend(i,:)];

  else


  end

    else 

          S50=[S50;Sckend(i,:)];


   end



end



prop=length(S50(:,1)) /length(Sckend(:,1))

length(S50(:,1)) 






% Contour with 25 % of people

S25=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S25(:,1))  < 0.250*length(Sckend(:,1))


      S25=[S25;Sckend(i,:)];

  else


  end

    else 

          S25=[S25;Sckend(i,:)];


   end



end



prop=length(S25(:,1)) /length(Sckend(:,1));

length(S25(:,1)) ;




  % Contour with 75 % of people

S75=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S75(:,1))  < 0.750*length(Sckend(:,1))


      S75=[S75;Sckend(i,:)];

  else


  end

    else 

          S75=[S75;Sckend(i,:)];


   end



end



prop=length(S75(:,1)) /length(Sckend(:,1));

length(S75(:,1));




 plot(x2,y2,'Marker','.','LineStyle','none','Color',[0.650980392156863 0.650980392156863 0.650980392156863])

 hold on;




k = boundary(S50(:,1),S50(:,2),0.9);

plot(S50(k,1),S50(k,2))

hold on;




k = boundary(S25(:,1),S25(:,2),0.9);

plot(S25(k,1),S25(k,2))

hold on;


hold on;

k = boundary(S75(:,1),S75(:,2),0.9);

plot(S75(k,1),S75(k,2))

hold on;

 xlabel('1/HOMA-IR')


  ylabel('HOMA-B')


  legend('','50%','25%','75%')
 

  figure(3)

    subplot(2,3,2)

 plot(x2,y2,'Marker','.','LineStyle','none','Color',[0.9 0.9 0.9])

 hold on;






k = boundary(S50(:,1),S50(:,2),0.9);


plot(S50(k,1),S50(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;


k = boundary(S25(:,1),S25(:,2),0.9);


plot(S25(k,1),S25(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;



k = boundary(S75(:,1),S75(:,2),0.9);

plot(S75(k,1),S75(k,2),'LineWidth',0.5,'Color',[0.65 0.65 0.65])

hold on;



 xlabel('1/HOMA-IR')


  ylabel('HOMA-B')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  Density Plot - Diabetic  - HOMA-B -HOMA-IR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(5)

subplot(2,2,1)

x=Diab(:,2);% Glucose

y=Diab(:,3);% Insulin


y2=20*y./(x-3.5) ; %HOMAB

x2=22.5./(x.*y); %1/HOMA_IR


xmax=max(x2);

xmin=min(x2);

[counts,centers] = hist(x2);

bar(centers,counts/trapz(centers,counts));



hold on;
% 



ksdensity(x2,'Support',[xmin*(1-0.0001) xmax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',0.05);




 
 xlabel('1/HOMA-IR')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);


subplot(2,2,2)



ymin=min(y2);

ymax=max(y2);

[counts,centers] = hist(y2)

bar(centers,counts/trapz(centers,counts))

hold on;

ksdensity(y2,'Support',[ymin*(1-0.0001) ymax*(1+0.0001)],'BoundaryCorrection','reflection','Bandwidth',5);


 xlabel('HOMA-B')
 
 ylabel('Probability')
 
 hold on;

set(gca,'FontName','Arial','FontSize',20);



subplot(2,2,3)



xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];



Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)]

ksdensity([x2 y2],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 5]);



ndata=length(x)

nmesh=length(ksdensity([x2 y2],xi,'Support','positive','BoundaryCorrection','reflection','Bandwidth',[0.05 5]))

 hold on

 xlabel('1/HOMA-IR')
 
 ylabel('HOMA-B')
 
 zlabel('Joint Probability')

hold on;


hold on;

subplot(2,2,4)




xgrid=linspace(xmin*(1-0.0001),xmax*(1+0.0001));

ygrid=linspace(ymin*(1-0.0001),ymax*(1+0.0001));

[x1,y1] = meshgrid(xgrid, ygrid);

xi = [x1(:) y1(:)];


Supp=[xmin*(1-0.0001) ymin*(1-0.0001);xmax*(1+0.0001) ymax*(1+0.0001)];





 xlabel('Fasting Glucose')
 
 ylabel('Fasting insulin')
 
 zlabel('Joint Probability')

hold on;


[fxy xy]=ksdensity([x2 y2],xi,'Support',Supp,'BoundaryCorrection','reflection','Bandwidth',[0.05 5]);



vq = griddata(xy(:,1),xy(:,2),fxy,x2,y2);


% 
Sck=[x2 y2 vq];

[Sckss,I] = sort(Sck(:,3),'descend');

Sckend=Sck(I,:);


% Contour with 50% of people

S50=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S50(:,1))  < 0.50*length(Sckend(:,1))


      S50=[S50;Sckend(i,:)];

  else


  end

    else 

          S50=[S50;Sckend(i,:)];


   end



end



prop=length(S50(:,1)) /length(Sckend(:,1))

length(S50(:,1)) 






% Contour with 25 % of people

S25=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S25(:,1))  < 0.250*length(Sckend(:,1))


      S25=[S25;Sckend(i,:)];

  else


  end

    else 

          S25=[S25;Sckend(i,:)];


   end



end



prop=length(S25(:,1)) /length(Sckend(:,1));

length(S25(:,1)) ;




  % Contour with 75 % of people

S75=[];

for i=1:length(Sckend(:,1))


    if i>1

  if length(S75(:,1))  < 0.750*length(Sckend(:,1))


      S75=[S75;Sckend(i,:)];

  else
  ylabel('HOMA-B')


 
 

  figure(3)

    %subplot(2,3,2)


  end

    else 

          S75=[S75;Sckend(i,:)];


   end



end



prop=length(S75(:,1)) /length(Sckend(:,1));

length(S75(:,1));




plot(x2,y2,'Marker','.','LineStyle','none','Color',[0.650980392156863 0.650980392156863 0.650980392156863])

 hold on;




k = boundary(S50(:,1),S50(:,2),0.9);

plot(S50(k,1),S50(k,2))

hold on;



k = boundary(S25(:,1),S25(:,2),0.9);

plot(S25(k,1),S25(k,2))

hold on;



hold on;

k = boundary(S75(:,1),S75(:,2),0.9);

plot(S75(k,1),S75(k,2))

hold on;

 xlabel('1/HOMA-IR')




plot(x2,y2,'Marker','.','LineStyle','none','Color',[0.9 0.9 0.9])

 hold on;





k = boundary(S50(:,1),S50(:,2),0.9);


plot(S50(k,1),S50(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;



k = boundary(S25(:,1),S25(:,2),0.9);


plot(S25(k,1),S25(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;



k = boundary(S75(:,1),S75(:,2),0.9);

plot(S75(k,1),S75(k,2),'LineWidth',0.5,'Color',[1 0 0])

hold on;



 xlabel('1/HOMA-IR')


  ylabel('HOMA-B')






x = 5.59:0.01:13.5;
y = 3:0.01:65;% 


[x1,y1] = meshgrid(sort(x),sort(y));



y2=20*y1./(x1-3.5) ; %HOMAB

x2=22.5./(x1.*y1); %1/HOMA_IR




v = 20*x1.*y1./((x1-3.5).*(x1-4.8));


hold on;




[c,h]=contour(x2,y2,v,10,'LineWidth', 2,'LevelList',[50 100 200 300 600 900 1200]);

clabel(c,h,'labelspacing', 700);



hold on;



xlabel('Insulin sensitivity (1/HOMA-IR)')

ylabel('HOMA-B')

set(gca,'FontName','Arial','FontSize',20);

pbaspect([1 1 1])


cb = colorbar; 

%ylabel(cb,'HOMA-C','FontSize',16,'Rotation',270)



title(cb,'HOMA-C');


set(gca, 'YScale', 'log')


xlim([0.025,1])



ylim([15,623])





  % Create textbox
annotation(figure(3),'textbox', [0.472527777777778 0.59481743227326 0.0170555555555554 0.0353356890459363], 'Color',[1 0 0],'String',{'75%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox',[0.461416666666667 0.639575971731446 0.024 0.0294464075382794],'Color',[1 0 0],'String',{'50%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox', [0.442666666666667 0.658421672555943 0.0177499999999998 0.0282685512367481],'Color',[1 0 0],'String',{'25%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');



  % Create textbox
annotation(figure(3),'textbox', [0.550305555555557 0.659599528857473 0.0170555555555554 0.0353356890459361], 'Color',[0.65 0.65 0.65],'String',{'75%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox',[0.521833333333335 0.67020023557126 0.0170555555555554 0.0341578327443954],'Color',[0.65 0.65 0.65],'String',{'50%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');

% Create textbox
annotation(figure(3),'textbox', [0.503083333333335 0.69140164899882 0.0170555555555554 0.0341578327443954],'Color',[0.65 0.65 0.65],'String',{'25%'},'FontSize',8,'FitBoxToText','off','EdgeColor','none');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  HOMA-C -  bar plot- Prediabetic vs Diabetic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



subplot(2,3,3)



ndiab=length(Diab(:,6));

npre=length(Prediab(:,6));


kpredred=randsample(npre,ndiab);



 x = [Prediab(kpredred,6);Diab(:,6)];

g = [zeros(length(Prediab(kpredred,6)),1); ones(length(Diab(:,6)), 1)];


plot(0,mean(Prediab(kpredred,6)),'Color',[0.65 0.65 0.65],'LineWidth',1)


hold on;



plot(1,mean(Diab(:,6)),'Color',[1 0 0],'LineWidth',1)


hold on;




boxplot(x, g,'Labels',{'Prediabetic','Diabetic'},'symbol' ,' ' ,'Colors',[0.65 0.65 0.65;1 0 0],'symbol' ,' ')




hold on;

ylabel('HOMA-C')

set(gca,'FontName','Arial','FontSize',20);

pbaspect([1 1 1])


legend('Prediabetic','Diabetic')




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  HOMA-C versus age
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



subplot(2,3,4)


plot(Prediab(:,4),Prediab(:,6),'Color',[0.65 0.65 0.65],'Marker','.', 'LineStyle','none','MarkerSize',4)

hold on;

plot(Diab(:,4),Diab(:,6),'Color',[1 0 0],'Marker','.', 'LineStyle','none','MarkerSize',4)

hold on;


xlabel('age (y)')

ylabel('HOMA-C')

set(gca,'FontName','Arial','FontSize',20);

pbaspect([1 1 1])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%  HOMA-C vs BMI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



subplot(2,3,5)


plot(Prediab(:,5),Prediab(:,6),'Color',[0.65 0.65 0.65],'Marker','.', 'LineStyle','none','MarkerSize',4)

hold on;

plot(Diab(:,5),Diab(:,6),'Color',[1 0 0],'Marker','.', 'LineStyle','none','MarkerSize',4)

hold on;

xlabel('BMI')

ylabel('HOMA-C')


%legend('Prediabetic','Diabetic')

set(gca,'FontName','Arial','FontSize',20);


pbaspect([1 1 1])

HOMA_C_prediab=mean(Prediab(kpredred,6))

HOMA_C_diab=mean(Diab(:,6))



close(figure(1))

close(figure(2))

close(figure(4))

close(figure(5))